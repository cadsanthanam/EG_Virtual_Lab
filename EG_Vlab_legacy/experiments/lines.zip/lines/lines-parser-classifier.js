/**
 * Enterprise Classifier - 5-slot counter + PROC matcher
 */
class ParserClassifier {
  constructor(config) {
    this.config = config || window.ParserConfig;
  }
  
  classify(extraction) {
    try {
      const {atoms, endpoints, specialFlags} = extraction;
      const constraints = this._buildConstraints(atoms, specialFlags);
      const slotCount = this._countSlots(atoms, specialFlags);
      const procMatch = this._matchProc(atoms, specialFlags);
      const caseType = this._detectCase(constraints);
      const completeness = this._assessCompleteness(slotCount, procMatch);
      
      return {
        constraints, procId:procMatch.procId, caseType,
        slotsConsumed:slotCount.total, slotDetails:slotCount.details,
        completeness, dataTypesFound:atoms.map(a=>a.dataType).concat(specialFlags.map(f=>f.id)),
        confidence:procMatch.confidence
      };
    } catch(err) {
      console.error('[Classifier] Error:', err);
      return {constraints:null, procId:null, caseType:null, slotsConsumed:0, completeness:{sufficient:false}, error:err.message};
    }
  }
  
  _buildConstraints(atoms, flags) {
    const c = {TL:null,theta:null,phi:null,alpha:null,beta:null,h_A:null,d_A:null,h_B:null,d_B:null,L_TV:null,L_FV:null,delta_X:null,h_mid:null,d_mid:null,VT_h:null,HT_d:null,special:[]};
    for(const f of flags) {
      if(f.effect.theta!==undefined) c.theta=f.effect.theta;
      if(f.effect.phi!==undefined) c.phi=f.effect.phi;
      if(f.flag==='ON_BOTH'||f.flag==='ON_XY') {c.h_A=0;c.d_A=0;}
      if(f.flag==='EQUAL_DIST_N'&&f.value) {c.h_A=f.value;c.d_A=f.value;}
      c.special.push(f.flag);
    }
    for(const a of atoms) c[a.field]=a.value;
    return c;
  }
  
  _countSlots(atoms, flags) {
    let total = atoms.length;
    const details = atoms.map(a=>({dataType:a.dataType,field:a.field,slots:1}));
    for(const f of flags) {
      if(f.slots>0) {
        total += f.slots;
        details.push({dataType:f.id,flag:f.flag,slots:f.slots});
      }
    }
    return {total, details};
  }
  
  _matchProc(atoms, flags) {
    const dtypes = new Set([...atoms.map(a=>a.dataType),...flags.filter(f=>f.slots>0).map(f=>f.id)]);
    let best = null, bestScore = 0;
    for(const proc of this.config.PROC_COMBINATIONS) {
      const req = new Set(proc.slots);
      let score = 0;
      for(const s of req) if(dtypes.has(s)) score++;
      const pct = score / req.size;
      if(pct > bestScore) {bestScore=pct; best=proc;}
    }
    return {procId:bestScore>=0.8?best?.procId:null, confidence:bestScore, nearestMatch:best};
  }
  
  _detectCase(c) {
    if(c.theta===90) return '2A';
    if(c.phi===90) return '2B';
    if(c.theta!==null&&c.phi!==null&&Math.abs(c.theta+c.phi-90)<0.5) return 'D★';
    if(c.theta>0&&c.phi>0&&c.theta+c.phi<90) return 'D';
    if(c.theta>0&&c.phi===0) return 'C';
    if(c.phi>0&&c.theta===0) return 'B';
    if(c.theta===0&&c.phi===0) return 'A';
    return null;
  }
  
  _assessCompleteness(slotCount, procMatch) {
    return {
      sufficient:slotCount.total>=5,
      slotsFound:slotCount.total,
      slotsRequired:5,
      missing:[],
      nearestProcId:procMatch.nearestMatch?.procId
    };
  }
}
if(typeof window!=='undefined')window.ParserClassifier=ParserClassifier;
