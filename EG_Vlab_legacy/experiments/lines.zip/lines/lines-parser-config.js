/**
 * lines-parser-config.js
 * Enterprise Configuration Module
 * Complete definitions: 18 data types, 13 special conditions, 28 PROC combinations
 * Version: 3.1.0 Enterprise
 */

const ParserConfig = {
  
  VERSION: '3.1.0',
  
  // ═══════════════════════════════════════════════════════════════════════
  // DATA TYPES (D01-D18) - Complete Definitions
  // ═══════════════════════════════════════════════════════════════════════
  
  DATA_TYPES: {
    D01: {
      id: 'D01', symbol: 'TL', name: 'True Length', field: 'TL', 
      slots: 1, unit: 'mm', domain: [0, Infinity],
      description: 'The actual 3D length of the line segment',
      phrases: ['long', 'length', 'true length', 'measures', 'in length', 'of length']
    },
    D02: {
      id: 'D02', symbol: 'θ', name: 'Inclination to HP', field: 'theta',
      slots: 1, unit: '°', domain: [0, 90],
      description: 'True angle measured from HP plane upward',
      phrases: ['to HP', 'with HP', 'to horizontal plane', 'inclination to HP']
    },
    D03: {
      id: 'D03', symbol: 'φ', name: 'Inclination to VP', field: 'phi',
      slots: 1, unit: '°', domain: [0, 90],
      description: 'True angle measured from VP plane forward',
      phrases: ['to VP', 'with VP', 'to vertical plane', 'inclination to VP']
    },
    D04: {
      id: 'D04', symbol: 'h_A', name: 'Height of end A', field: 'h_A',
      slots: 1, unit: 'mm', domain: [-Infinity, Infinity],
      description: 'Perpendicular distance of A from HP (above=+, below=-)',
      phrases: ['above HP', 'below HP', 'from HP']
    },
    D05: {
      id: 'D05', symbol: 'd_A', name: 'Depth of end A', field: 'd_A',
      slots: 1, unit: 'mm', domain: [-Infinity, Infinity],
      description: 'Perpendicular distance of A from VP (front=+, behind=-)',
      phrases: ['in front of VP', 'behind VP', 'from VP']
    },
    D06: {
      id: 'D06', symbol: 'h_B', name: 'Height of end B', field: 'h_B',
      slots: 1, unit: 'mm', domain: [-Infinity, Infinity],
      description: 'Perpendicular distance of B from HP',
      phrases: ['above HP', 'below HP', 'from HP']
    },
    D07: {
      id: 'D07', symbol: 'd_B', name: 'Depth of end B', field: 'd_B',
      slots: 1, unit: 'mm', domain: [-Infinity, Infinity],
      description: 'Perpendicular distance of B from VP',
      phrases: ['in front of VP', 'behind VP', 'from VP']
    },
    D08: {
      id: 'D08', symbol: 'L_TV', name: 'Top View length', field: 'L_TV',
      slots: 1, unit: 'mm', domain: [0, Infinity],
      description: 'Projected length in horizontal plane (plan)',
      phrases: ['top view', 'plan', 'TV', 'horizontal projection']
    },
    D09: {
      id: 'D09', symbol: 'L_FV', name: 'Front View length', field: 'L_FV',
      slots: 1, unit: 'mm', domain: [0, Infinity],
      description: 'Projected length in vertical plane (elevation)',
      phrases: ['front view', 'elevation', 'FV', 'vertical projection']
    },
    D10: {
      id: 'D10', symbol: 'α', name: 'TV angle with XY', field: 'alpha',
      slots: 1, unit: '°', domain: [0, 90],
      description: 'Apparent (not true) angle in top view',
      phrases: ['plan makes', 'top view makes', 'TV makes', 'plan at']
    },
    D11: {
      id: 'D11', symbol: 'β', name: 'FV angle with XY', field: 'beta',
      slots: 1, unit: '°', domain: [0, 90],
      description: 'Apparent (not true) angle in front view',
      phrases: ['front view makes', 'elevation makes', 'FV makes']
    },
    D12: {
      id: 'D12', symbol: 'Δx', name: 'Projector distance', field: 'delta_X',
      slots: 1, unit: 'mm', domain: [0, Infinity],
      description: 'Horizontal distance between projectors of A and B',
      phrases: ['projectors apart', 'distance between projectors', 'end projectors']
    },
    D13: {
      id: 'D13', symbol: 'h_mid', name: 'Midpoint height', field: 'h_mid',
      slots: 1, unit: 'mm', domain: [-Infinity, Infinity],
      description: 'Height of midpoint M above HP',
      phrases: ['midpoint above HP', 'mid-point above HP', 'centre above HP']
    },
    D14: {
      id: 'D14', symbol: 'd_mid', name: 'Midpoint depth', field: 'd_mid',
      slots: 1, unit: 'mm', domain: [-Infinity, Infinity],
      description: 'Depth of midpoint M from VP',
      phrases: ['midpoint in front of VP', 'mid-point from VP', 'centre from VP']
    },
    D15: {
      id: 'D15', symbol: 'VT_h', name: 'VT height', field: 'VT_h',
      slots: 1, unit: 'mm', domain: [-Infinity, Infinity],
      description: 'Height where line (extended) meets VP',
      phrases: ['VT above HP', 'vertical trace', 'VT is']
    },
    D16: {
      id: 'D16', symbol: 'HT_d', name: 'HT depth', field: 'HT_d',
      slots: 1, unit: 'mm', domain: [-Infinity, Infinity],
      description: 'Depth where line (extended) meets HP',
      phrases: ['HT in front of VP', 'horizontal trace', 'HT is']
    },
    D17: {
      id: 'D17', symbol: 'L_SV', name: 'Side View length', field: 'L_SV',
      slots: 1, unit: 'mm', domain: [0, Infinity],
      description: 'Projected length in Profile Plane (rare)',
      phrases: ['side view', 'profile view', 'SV']
    },
    D18: {
      id: 'D18', symbol: 'γ', name: 'Inclination to PP', field: 'gamma',
      slots: 1, unit: '°', domain: [0, 90],
      description: 'True angle with Profile Plane (rare)',
      phrases: ['to profile plane', 'to PP', 'with profile plane']
    }
  },
  
  // ═══════════════════════════════════════════════════════════════════════
  // SPECIAL CONDITIONS (SK01-SK13) - Complete with 2-slot tracking
  // ═══════════════════════════════════════════════════════════════════════
  
  SPECIAL_CONDITIONS: {
    SK01: {
      id: 'SK01', flag: 'PARALLEL_HP', slots: 1,
      effect: { theta: 0 },
      description: 'Line parallel to HP → θ=0',
      phrases: ['parallel to HP', '∥ HP', 'parallel to horizontal plane'],
      priority: 5
    },
    SK02: {
      id: 'SK02', flag: 'PARALLEL_VP', slots: 1,
      effect: { phi: 0 },
      description: 'Line parallel to VP → φ=0',
      phrases: ['parallel to VP', '∥ VP', 'parallel to vertical plane'],
      priority: 5
    },
    SK03: {
      id: 'SK03', flag: 'PERP_HP', slots: 1,
      effect: { theta: 90 },
      description: 'Line perpendicular to HP → θ=90 (vertical)',
      phrases: ['perpendicular to HP', '⊥ HP', 'vertical line'],
      priority: 10
    },
    SK04: {
      id: 'SK04', flag: 'PERP_VP', slots: 1,
      effect: { phi: 90 },
      description: 'Line perpendicular to VP → φ=90',
      phrases: ['perpendicular to VP', '⊥ VP'],
      priority: 10
    },
    SK05: {
      id: 'SK05', flag: 'ON_HP', slots: 1,
      effect: { h: 0 },
      description: 'Endpoint on HP → h=0',
      phrases: ['in HP', 'on HP', 'lies in HP', 'lies on HP'],
      priority: 7
    },
    SK06: {
      id: 'SK06', flag: 'ON_VP', slots: 1,
      effect: { d: 0 },
      description: 'Endpoint on VP → d=0',
      phrases: ['in VP', 'on VP', 'lies in VP', 'lies on VP'],
      priority: 7
    },
    SK07: {
      id: 'SK07', flag: 'ON_BOTH', slots: 2,  // CRITICAL: 2 slots!
      effect: { h: 0, d: 0 },
      description: 'Endpoint on both HP and VP → h=0 AND d=0',
      phrases: ['on both HP and VP', 'on HP and VP', 'lies on both', 'in both'],
      priority: 15
    },
    SK08: {
      id: 'SK08', flag: 'EQUAL_DIST_N', slots: 2,  // CRITICAL: 2 slots!
      effect: { h: 'N', d: 'N' },
      description: 'Equal distance from both planes → h=N AND d=N',
      phrases: ['from both HP and VP', 'from both planes', 'mm from both'],
      priority: 15
    },
    SK09: {
      id: 'SK09', flag: 'EQUAL_DIST_UNK', slots: 1,
      effect: { constraint: 'h=d' },
      description: 'Equidistant from both (unknown value) → h=d constraint',
      phrases: ['equidistant from both', 'equal distances from both'],
      priority: 8
    },
    SK10: {
      id: 'SK10', flag: 'ON_XY', slots: 2,  // CRITICAL: 2 slots!
      effect: { h: 0, d: 0 },
      description: 'Line intersects XY at endpoint → h=0 AND d=0',
      phrases: ['intersects XY', 'meets XY', 'crosses XY', 'on XY'],
      priority: 15
    },
    SK11: {
      id: 'SK11', flag: 'MIDPOINT', slots: 0,
      effect: {},
      description: 'Routing flag: h/d values are for midpoint M',
      phrases: ['midpoint', 'mid-point', 'centre of line', 'center of line'],
      priority: 3
    },
    SK12: {
      id: 'SK12', flag: 'TRACE_REQ', slots: 0,
      effect: {},
      description: 'Post-processing flag: find and mark traces',
      phrases: ['mark traces', 'find traces', 'show traces', 'HT and VT'],
      priority: 1
    },
    SK13: {
      id: 'SK13', flag: 'FIRST_QUAD', slots: 0,
      effect: {},
      description: 'Context flag: confirms h>0, d>0',
      phrases: ['in first quadrant', 'first quadrant'],
      priority: 1
    }
  },
  
  // ═══════════════════════════════════════════════════════════════════════
  // PROC COMBINATIONS (All 28) - Production Ready
  // ═══════════════════════════════════════════════════════════════════════
  
  PROC_COMBINATIONS: [
    // GROUP A: Standard (TL + both angles + endpoint)
    { procId: 'PROC-01', name: 'Canonical Oblique', slots: ['D01','D02','D03','D04','D05'], caseType: 'D', priority: 100 },
    { procId: 'PROC-02', name: 'Oblique from B', slots: ['D01','D02','D03','D06','D07'], caseType: 'D', priority: 95 },
    { procId: 'PROC-03', name: 'Oblique Midpoint', slots: ['D01','D02','D03','D13','D14'], caseType: 'D', priority: 90 },
    { procId: 'PROC-04', name: 'Inclined to HP only', slots: ['D01','D02','SK02','D04','D05'], caseType: 'C', priority: 85 },
    { procId: 'PROC-05', name: 'Inclined to VP only', slots: ['D01','SK01','D03','D04','D05'], caseType: 'B', priority: 85 },
    { procId: 'PROC-06', name: 'Parallel to both', slots: ['D01','SK01','SK02','D04','D05'], caseType: 'A', priority: 80 },
    { procId: 'PROC-07', name: 'Perpendicular to HP', slots: ['D01','SK03','SK02','D04','D05'], caseType: '2A', priority: 75 },
    { procId: 'PROC-08', name: 'Perpendicular to VP', slots: ['D01','SK01','SK04','D04','D05'], caseType: '2B', priority: 75 },
    
    // GROUP B: Projected Lengths
    { procId: 'PROC-09', name: 'L_TV with both angles', slots: ['D08','D02','D03','D04','D05'], caseType: 'D', priority: 70 },
    { procId: 'PROC-10', name: 'L_FV with both angles', slots: ['D09','D02','D03','D04','D05'], caseType: 'D', priority: 70 },
    { procId: 'PROC-11', name: 'L_TV inclined to HP', slots: ['D08','D02','SK02','D04','D05'], caseType: 'C', priority: 65 },
    { procId: 'PROC-12', name: 'L_FV inclined to VP', slots: ['D09','SK01','D03','D04','D05'], caseType: 'B', priority: 65 },
    { procId: 'PROC-13', name: 'Both views + Δx', slots: ['D08','D09','D04','D05','D12'], caseType: 'D', priority: 60 },
    { procId: 'PROC-14', name: 'Both views no Δx', slots: ['D08','D09','D04','D05'], caseType: 'D', priority: 55 },
    
    // GROUP C: Apparent Angles
    { procId: 'PROC-15', name: 'TL with apparent angles', slots: ['D01','D10','D11','D04','D05'], caseType: 'D', priority: 50 },
    { procId: 'PROC-16', name: 'L_TV, α, h_B', slots: ['D08','D10','D04','D05','D06'], caseType: 'D', priority: 45 },
    { procId: 'PROC-17', name: 'L_FV, β, d_B', slots: ['D09','D11','D04','D05','D07'], caseType: 'D', priority: 45 },
    { procId: 'PROC-18', name: 'TL, α, h_B', slots: ['D01','D10','D04','D05','D06'], caseType: 'D', priority: 40 },
    { procId: 'PROC-19', name: 'TL, β, d_B', slots: ['D01','D11','D04','D05','D07'], caseType: 'D', priority: 40 },
    
    // GROUP D: Both Endpoints
    { procId: 'PROC-20', name: 'TL + both endpoints', slots: ['D01','D04','D05','D06','D07'], caseType: 'D', priority: 35 },
    { procId: 'PROC-21', name: 'Find TL from positions', slots: ['D04','D05','D06','D07','D12'], caseType: 'D', priority: 30 },
    { procId: 'PROC-22', name: 'TL, A, h_B, Δx', slots: ['D01','D04','D05','D06','D12'], caseType: 'D', priority: 25 },
    { procId: 'PROC-23', name: 'TL, A, d_B, Δx', slots: ['D01','D04','D05','D07','D12'], caseType: 'D', priority: 25 },
    
    // GROUP E: Projector Distance
    { procId: 'PROC-24', name: 'TL, θ, Δx', slots: ['D01','D02','D04','D05','D12'], caseType: 'D', priority: 20 },
    { procId: 'PROC-25', name: 'TL, φ, Δx', slots: ['D01','D03','D04','D05','D12'], caseType: 'D', priority: 20 },
    { procId: 'PROC-26', name: 'L_FV, β, h_B', slots: ['D09','D11','D04','D05','D06'], caseType: 'D', priority: 15 },
    
    // GROUP F: Traces
    { procId: 'PROC-27', name: 'Base + Traces', slots: ['D01','D02','D03','D04','SK12'], caseType: 'D', priority: 10 },
    { procId: 'PROC-28', name: 'VT as 5th datum', slots: ['D09','D03','D04','D06','D15'], caseType: 'D', priority: 5 }
  ],
  
  // ═══════════════════════════════════════════════════════════════════════
  // UTILITY METHODS
  // ═══════════════════════════════════════════════════════════════════════
  
  getDataType(id) {
    return this.DATA_TYPES[id] || null;
  },
  
  getSpecialCondition(id) {
    return this.SPECIAL_CONDITIONS[id] || null;
  },
  
  getProcById(procId) {
    return this.PROC_COMBINATIONS.find(p => p.procId === procId) || null;
  },
  
  validateSlotCount(count) {
    return count === 5;
  },
  
  getFieldDomain(field) {
    for (const dtype of Object.values(this.DATA_TYPES)) {
      if (dtype.field === field) return dtype.domain;
    }
    return null;
  }
};

// Export
if (typeof window !== 'undefined') window.ParserConfig = ParserConfig;
if (typeof module !== 'undefined' && module.exports) module.exports = ParserConfig;
