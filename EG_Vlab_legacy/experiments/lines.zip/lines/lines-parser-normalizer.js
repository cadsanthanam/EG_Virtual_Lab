/**
 * lines-parser-normalizer.js
 * Enterprise Text Normalization Module
 * Critical fixes: degree symbols, unit conversion, plane abbreviations
 * Version: 3.1.0 Enterprise
 */

class ParserNormalizer {
  
  constructor(config) {
    this.config = config || (typeof window !== 'undefined' ? window.ParserConfig : null);
    this.stats = {
      totalNormalizations: 0,
      degreeFixes: 0,
      unitConversions: 0,
      abbreviationExpansions: 0
    };
  }
  
  /**
   * Main normalization entry point
   * @param {string} text - Raw input text
   * @returns {object} - {normalized: string, metadata: object}
   */
  normalize(text) {
    if (!text || typeof text !== 'string') {
      return { normalized: '', metadata: { error: 'Invalid input' } };
    }
    
    const original = text;
    let normalized = text;
    const changes = [];
    
    try {
      // Step 1: Lowercase (preserve original for endpoint detection)
      normalized = normalized.toLowerCase();
      
      // Step 2: Normalize degree symbols (CRITICAL - must be first)
      const degreeResult = this._normalizeDegrees(normalized);
      normalized = degreeResult.text;
      if (degreeResult.changed) changes.push('degree_normalization');
      
      // Step 3: Convert units to mm
      const unitResult = this._convertUnits(normalized);
      normalized = unitResult.text;
      if (unitResult.changed) changes.push('unit_conversion');
      
      // Step 4: Normalize plane abbreviations
      const planeResult = this._normalizePlanes(normalized);
      normalized = planeResult.text;
      if (planeResult.changed) changes.push('plane_abbreviation');
      
      // Step 5: Expand abbreviations
      const abbrevResult = this._expandAbbreviations(normalized);
      normalized = abbrevResult.text;
      if (abbrevResult.changed) changes.push('abbreviation_expansion');
      
      // Step 6: Clean whitespace
      normalized = this._cleanWhitespace(normalized);
      
      this.stats.totalNormalizations++;
      
      return {
        normalized,
        metadata: {
          originalLength: original.length,
          normalizedLength: normalized.length,
          changes,
          stats: {...this.stats}
        }
      };
      
    } catch (err) {
      console.error('[Normalizer] Error:', err);
      return {
        normalized: original.toLowerCase(),
        metadata: { error: err.message, changes }
      };
    }
  }
  
  /**
   * CRITICAL: Normalize degree symbols with proper regex
   * Bug fix: "40 deg to VP" → "40° to VP" (NOT "40°g to VP")
   */
  _normalizeDegrees(text) {
    let changed = false;
    let result = text;
    
    // Handle Unicode variants
    if (/º|˚/.test(result)) {
      result = result.replace(/º/g, '°').replace(/˚/g, '°');
      changed = true;
    }
    
    // CRITICAL FIX: "degrees" → "°" (must come before "degree")
    if (/\d+(?:\.\d+)?\s*degrees?(?![a-z])/i.test(result)) {
      result = result.replace(/(\d+(?:\.\d+)?)\s*degrees?(?![a-z])/gi, '$1°');
      changed = true;
      this.stats.degreeFixes++;
    }
    
    // CRITICAL FIX: "deg" → "°" with negative lookahead
    // (?![a-z]) prevents matching "deg" in "degree"
    if (/\d+(?:\.\d+)?\s*deg(?![a-z])/i.test(result)) {
      result = result.replace(/(\d+(?:\.\d+)?)\s*deg(?![a-z])/gi, '$1°');
      changed = true;
      this.stats.degreeFixes++;
    }
    
    // Clean up multiple degree symbols
    result = result.replace(/°+/g, '°');
    
    return { text: result, changed };
  }
  
  /**
   * Convert cm and m to mm
   */
  _convertUnits(text) {
    let changed = false;
    let result = text;
    
    // Convert cm to mm (multiply by 10)
    if (/\d+(?:\.\d+)?\s*cm(?![a-z])/i.test(result)) {
      result = result.replace(/(\d+(?:\.\d+)?)\s*cm(?![a-z])/gi, (match, num) => {
        changed = true;
        this.stats.unitConversions++;
        return `${parseFloat(num) * 10}mm`;
      });
    }
    
    // Convert m to mm (multiply by 1000)
    if (/\d+(?:\.\d+)?\s*m(?![a-z])/i.test(result)) {
      result = result.replace(/(\d+(?:\.\d+)?)\s*m(?![a-z])/gi, (match, num) => {
        changed = true;
        this.stats.unitConversions++;
        return `${parseFloat(num) * 1000}mm`;
      });
    }
    
    return { text: result, changed };
  }
  
  /**
   * Normalize plane abbreviations
   */
  _normalizePlanes(text) {
    let changed = false;
    let result = text;
    
    const replacements = [
      [/\bh\.p\./gi, 'HP'],
      [/\bhorizontal\s+plane\b/gi, 'HP'],
      [/\bv\.p\./gi, 'VP'],
      [/\bvertical\s+plane\b/gi, 'VP'],
      [/\bp\.p\./gi, 'PP'],
      [/\bprofile\s+plane\b/gi, 'PP']
    ];
    
    for (const [pattern, replacement] of replacements) {
      if (pattern.test(result)) {
        result = result.replace(pattern, replacement);
        changed = true;
      }
    }
    
    return { text: result, changed };
  }
  
  /**
   * Expand common abbreviations
   */
  _expandAbbreviations(text) {
    let changed = false;
    let result = text;
    
    const expansions = [
      // View abbreviations
      [/\bf\.v\./gi, 'front view'],
      [/\bt\.v\./gi, 'top view'],
      [/\bs\.v\./gi, 'side view'],
      // Projection synonyms
      [/\belevation\b/gi, 'front view'],
      [/\bplan\b/gi, 'top view'],
      // Distance words (normalize spacing)
      [/\bin\s+front\s+of\b/gi, 'in front of'],
      // Line references
      [/\bstraight\s+line\b/gi, 'line']
    ];
    
    for (const [pattern, replacement] of expansions) {
      if (pattern.test(result)) {
        result = result.replace(pattern, replacement);
        changed = true;
        this.stats.abbreviationExpansions++;
      }
    }
    
    return { text: result, changed };
  }
  
  /**
   * Clean and normalize whitespace
   */
  _cleanWhitespace(text) {
    return text
      .replace(/\s+/g, ' ')      // Multiple spaces → single space
      .replace(/\s*,\s*/g, ', ') // Normalize comma spacing
      .replace(/\s*\.\s*/g, '. ') // Normalize period spacing
      .trim();
  }
  
  /**
   * Get normalization statistics
   */
  getStats() {
    return { ...this.stats };
  }
  
  /**
   * Reset statistics
   */
  resetStats() {
    this.stats = {
      totalNormalizations: 0,
      degreeFixes: 0,
      unitConversions: 0,
      abbreviationExpansions: 0
    };
  }
}

// Export
if (typeof window !== 'undefined') window.ParserNormalizer = ParserNormalizer;
if (typeof module !== 'undefined' && module.exports) module.exports = ParserNormalizer;
