/**
 * Enterprise Validator
 */
class ParserValidator {
  validate(constraints) {
    const errors=[], warnings=[];
    if(constraints.TL!==null&&constraints.TL<0) errors.push('TL must be positive');
    if(constraints.theta!==null&&(constraints.theta<0||constraints.theta>90)) errors.push('θ must be in [0°,90°]');
    if(constraints.phi!==null&&(constraints.phi<0||constraints.phi>90)) errors.push('φ must be in [0°,90°]');
    if(constraints.theta!==null&&constraints.phi!==null&&constraints.theta+constraints.phi>90.5) errors.push('θ+φ cannot exceed 90°');
    return {valid:errors.length===0, errors, warnings, summary:errors.length?errors.join('; '):'All valid'};
  }
}
if(typeof window!=='undefined')window.ParserValidator=ParserValidator;
